import React from 'react';
import "./styles.css";

const Header = () => <header id="main-header">ReactJS Header</header>;

export default Header;